import Header from "@/components/header";
import Footer from "@/components/footer";
import CourseCard from "@/components/course-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Courses() {
  const courses = [
    {
      title: "Azure DevOps Mastery",
      badge: "Professional",
      badgeColor: "blue" as const,
      students: "150+",
      rating: "4.9",
      level: "Intermediate to Advanced Level",
      features: [
        "Azure Pipelines & CI/CD automation",
        "Infrastructure as Code with ARM/Bicep",
        "Container orchestration & monitoring",
        "Azure security & compliance automation",
        "Career transition & certification support"
      ],
      isPopular: true
    },
    {
      title: "AWS DevOps Professional", 
      badge: "Professional",
      badgeColor: "orange" as const,
      students: "120+",
      rating: "4.8",
      level: "Intermediate to Advanced Level", 
      features: [
        "AWS CodePipeline & CodeDeploy mastery",
        "Terraform & CloudFormation IaC",
        "EKS, Lambda & serverless automation",
        "AWS security best practices",
        "AWS certification preparation"
      ]
    },
    {
      title: "AI-Powered DevOps",
      badge: "Advanced",
      badgeColor: "purple" as const,
      students: "80+",
      rating: "4.9",
      level: "Advanced Level",
      features: [
        "AI-driven monitoring & alerting",
        "Machine learning for operations", 
        "Automated incident response",
        "Predictive analytics for infrastructure",
        "AI strategy for enterprise DevOps"
      ]
    },
    {
      title: "Multi-Cloud DevOps",
      badge: "Professional", 
      badgeColor: "green" as const,
      students: "90+",
      rating: "4.7",
      level: "Advanced Level",
      features: [
        "Cross-platform CI/CD pipelines",
        "Multi-cloud infrastructure management",
        "Cloud-agnostic monitoring solutions",
        "Cost optimization strategies",
        "Vendor lock-in prevention"
      ]
    },
    {
      title: "DevSecOps Fundamentals",
      badge: "Security Focus",
      badgeColor: "blue" as const, 
      students: "75+",
      rating: "4.8",
      level: "Intermediate Level",
      features: [
        "Security-first development practices",
        "Automated security testing",
        "Compliance automation",
        "Vulnerability management",
        "Security monitoring & incident response"
      ]
    },
    {
      title: "Cloud Native Kubernetes",
      badge: "Container Focus",
      badgeColor: "purple" as const,
      students: "110+", 
      rating: "4.9",
      level: "Intermediate to Advanced Level",
      features: [
        "Kubernetes cluster management",
        "Container orchestration patterns",
        "Service mesh implementation",
        "Cloud-native security",
        "GitOps workflows"
      ]
    }
  ];

  const courseCategories = [
    {
      title: "Foundation Courses",
      description: "Perfect for beginners entering the DevOps world",
      courseCount: 3,
      duration: "2-3 months",
      level: "Beginner"
    },
    {
      title: "Professional Courses", 
      description: "Advanced training for experienced professionals",
      courseCount: 4,
      duration: "3-4 months", 
      level: "Intermediate"
    },
    {
      title: "Expert Masterclasses",
      description: "Specialized training for senior roles",
      courseCount: 2,
      duration: "1-2 months",
      level: "Advanced"
    }
  ];

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">Our Courses</h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Comprehensive DevOps and cloud training programs designed to accelerate your career
            </p>
          </div>

          {/* Course Categories */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {courseCategories.map((category, index) => (
              <Card key={index} className="text-center">
                <CardContent className="p-8">
                  <Badge className="mb-4 text-sm">{category.level}</Badge>
                  <h3 className="text-xl font-bold text-foreground mb-4">{category.title}</h3>
                  <p className="text-muted-foreground mb-6">{category.description}</p>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p><strong>{category.courseCount}</strong> courses available</p>
                    <p><strong>{category.duration}</strong> duration</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* All Courses */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-8 text-center">All Courses</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {courses.map((course, index) => (
                <CourseCard key={index} {...course} />
              ))}
            </div>
          </div>

          {/* Course Features */}
          <div className="bg-secondary/30 rounded-2xl p-8 mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-8 text-center">What's Included in Every Course</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-blue-600 text-2xl">📚</span>
                </div>
                <h3 className="font-semibold text-foreground mb-2">Comprehensive Materials</h3>
                <p className="text-sm text-muted-foreground">Detailed documentation, guides, and resources</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-green-600 text-2xl">💻</span>
                </div>
                <h3 className="font-semibold text-foreground mb-2">Hands-on Labs</h3>
                <p className="text-sm text-muted-foreground">Real-world projects and practical exercises</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-purple-600 text-2xl">🎓</span>
                </div>
                <h3 className="font-semibold text-foreground mb-2">Certification</h3>
                <p className="text-sm text-muted-foreground">Industry-recognized certificates upon completion</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-orange-600 text-2xl">🤝</span>
                </div>
                <h3 className="font-semibold text-foreground mb-2">Placement Support</h3>
                <p className="text-sm text-muted-foreground">Career guidance and job placement assistance</p>
              </div>
            </div>
          </div>

          {/* CTA Section */}
          <div className="text-center">
            <h2 className="text-3xl font-bold text-foreground mb-6">Ready to Start Your Journey?</h2>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Join thousands of professionals who have transformed their careers with our DevOps training programs
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" data-testid="contact-advisor-button">
                Contact Our Advisor
              </Button>
              <Button variant="outline" size="lg" data-testid="download-brochure-button">
                Download Brochure
              </Button>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
