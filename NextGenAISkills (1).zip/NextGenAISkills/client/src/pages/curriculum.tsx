import Header from "@/components/header";
import Footer from "@/components/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Check, Clock, Users, Award } from "lucide-react";

export default function Curriculum() {
  const curriculumData = {
    "azure-devops": {
      title: "Azure DevOps Mastery",
      duration: "16 weeks",
      level: "Intermediate to Advanced",
      modules: [
        {
          week: "Weeks 1-2",
          title: "Azure Fundamentals & DevOps Introduction",
          topics: [
            "Azure cloud platform overview",
            "DevOps culture and principles",
            "Azure DevOps Services introduction",
            "Setting up development environment"
          ]
        },
        {
          week: "Weeks 3-5", 
          title: "Azure Pipelines & CI/CD",
          topics: [
            "Build pipelines creation and management",
            "Release pipelines and deployment strategies",
            "YAML pipeline configuration",
            "Integration with Git repositories"
          ]
        },
        {
          week: "Weeks 6-8",
          title: "Infrastructure as Code",
          topics: [
            "ARM templates development",
            "Bicep language fundamentals", 
            "Azure Resource Manager integration",
            "Infrastructure automation best practices"
          ]
        },
        {
          week: "Weeks 9-11",
          title: "Container & Orchestration",
          topics: [
            "Docker containerization",
            "Azure Container Instances (ACI)",
            "Azure Kubernetes Service (AKS)",
            "Container registry management"
          ]
        },
        {
          week: "Weeks 12-14",
          title: "Monitoring & Security",
          topics: [
            "Azure Monitor and Application Insights",
            "Security best practices",
            "Compliance automation",
            "Incident response strategies"
          ]
        },
        {
          week: "Weeks 15-16",
          title: "Capstone Project & Certification",
          topics: [
            "End-to-end DevOps project",
            "Azure certification preparation",
            "Career guidance and interview prep",
            "Portfolio development"
          ]
        }
      ]
    },
    "aws-devops": {
      title: "AWS DevOps Professional",
      duration: "14 weeks",
      level: "Intermediate to Advanced", 
      modules: [
        {
          week: "Weeks 1-2",
          title: "AWS Fundamentals & DevOps Foundation",
          topics: [
            "AWS core services overview",
            "DevOps methodologies and best practices",
            "AWS CLI and SDK setup",
            "IAM roles and security fundamentals"
          ]
        },
        {
          week: "Weeks 3-4",
          title: "AWS CodeSuite Services",
          topics: [
            "CodeCommit for source control",
            "CodeBuild for continuous integration", 
            "CodeDeploy for automated deployment",
            "CodePipeline for workflow orchestration"
          ]
        },
        {
          week: "Weeks 5-7",
          title: "Infrastructure as Code",
          topics: [
            "CloudFormation templates",
            "Terraform with AWS",
            "AWS CDK fundamentals",
            "Infrastructure automation patterns"
          ]
        },
        {
          week: "Weeks 8-10",
          title: "Containerization & Serverless",
          topics: [
            "Docker and Amazon ECR",
            "Amazon EKS cluster management",
            "AWS Lambda functions",
            "Serverless application patterns"
          ]
        },
        {
          week: "Weeks 11-12",
          title: "Monitoring & Optimization",
          topics: [
            "CloudWatch monitoring and alerting",
            "AWS X-Ray for tracing",
            "Cost optimization strategies",
            "Performance tuning techniques"
          ]
        },
        {
          week: "Weeks 13-14",
          title: "Project & Certification Prep",
          topics: [
            "Real-world AWS DevOps project",
            "AWS certification guidance",
            "Interview preparation",
            "Portfolio showcase development"
          ]
        }
      ]
    },
    "ai-devops": {
      title: "AI-Powered DevOps",
      duration: "12 weeks",
      level: "Advanced",
      modules: [
        {
          week: "Weeks 1-2",
          title: "AI/ML Fundamentals for DevOps",
          topics: [
            "Machine learning basics for operations",
            "AI integration in DevOps workflows",
            "Data preparation and analysis",
            "MLOps introduction and principles"
          ]
        },
        {
          week: "Weeks 3-4", 
          title: "Intelligent Monitoring & Alerting",
          topics: [
            "AI-driven monitoring solutions",
            "Anomaly detection algorithms",
            "Predictive alerting systems",
            "Machine learning for log analysis"
          ]
        },
        {
          week: "Weeks 5-6",
          title: "Automated Incident Response",
          topics: [
            "AI-powered incident detection",
            "Automated remediation strategies",
            "Chatbot integration for operations",
            "Self-healing infrastructure patterns"
          ]
        },
        {
          week: "Weeks 7-8",
          title: "Predictive Analytics",
          topics: [
            "Capacity planning with ML",
            "Performance prediction models",
            "Resource optimization algorithms",
            "Cost forecasting and optimization"
          ]
        },
        {
          week: "Weeks 9-10",
          title: "AI Strategy & Implementation",
          topics: [
            "Enterprise AI strategy for DevOps",
            "Tool selection and integration",
            "Change management for AI adoption",
            "ROI measurement and optimization"
          ]
        },
        {
          week: "Weeks 11-12",
          title: "Advanced Project & Future Trends",
          topics: [
            "Complete AI-DevOps implementation",
            "Emerging technologies and trends",
            "Career advancement in AI-DevOps",
            "Building AI-first organizations"
          ]
        }
      ]
    }
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">Course Curriculum</h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Detailed curriculum breakdown for our comprehensive DevOps training programs
            </p>
          </div>

          <Tabs defaultValue="azure-devops" className="w-full">
            <TabsList className="grid w-full grid-cols-1 md:grid-cols-3 h-auto mb-8">
              <TabsTrigger value="azure-devops" className="p-4" data-testid="azure-devops-tab">
                Azure DevOps Mastery
              </TabsTrigger>
              <TabsTrigger value="aws-devops" className="p-4" data-testid="aws-devops-tab">
                AWS DevOps Professional  
              </TabsTrigger>
              <TabsTrigger value="ai-devops" className="p-4" data-testid="ai-devops-tab">
                AI-Powered DevOps
              </TabsTrigger>
            </TabsList>

            {Object.entries(curriculumData).map(([key, curriculum]) => (
              <TabsContent key={key} value={key} className="space-y-8">
                {/* Course Overview */}
                <Card>
                  <CardContent className="p-8">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                      <div className="text-center">
                        <Clock className="w-8 h-8 text-primary mx-auto mb-2" />
                        <h3 className="font-semibold text-foreground mb-1">Duration</h3>
                        <p className="text-muted-foreground">{curriculum.duration}</p>
                      </div>
                      <div className="text-center">
                        <Award className="w-8 h-8 text-primary mx-auto mb-2" />
                        <h3 className="font-semibold text-foreground mb-1">Level</h3>
                        <p className="text-muted-foreground">{curriculum.level}</p>
                      </div>
                      <div className="text-center">
                        <Users className="w-8 h-8 text-primary mx-auto mb-2" />
                        <h3 className="font-semibold text-foreground mb-1">Format</h3>
                        <p className="text-muted-foreground">Live + Hands-on</p>
                      </div>
                      <div className="text-center">
                        <Check className="w-8 h-8 text-primary mx-auto mb-2" />
                        <h3 className="font-semibold text-foreground mb-1">Certification</h3>
                        <p className="text-muted-foreground">Industry Recognized</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Curriculum Modules */}
                <div className="space-y-6">
                  <h2 className="text-3xl font-bold text-foreground mb-8">Course Modules</h2>
                  {curriculum.modules.map((module, index) => (
                    <Card key={index}>
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <Badge className="shrink-0 mt-1">{module.week}</Badge>
                          <div className="flex-1">
                            <h3 className="text-xl font-bold text-foreground mb-4">{module.title}</h3>
                            <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                              {module.topics.map((topic, topicIndex) => (
                                <li key={topicIndex} className="flex items-start gap-2">
                                  <Check className="w-4 h-4 text-green-500 mt-1 shrink-0" />
                                  <span className="text-muted-foreground">{topic}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Additional Features */}
                <Card>
                  <CardContent className="p-8">
                    <h3 className="text-2xl font-bold text-foreground mb-6">Additional Course Features</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      <div className="text-center">
                        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <span className="text-blue-600 text-2xl">🔬</span>
                        </div>
                        <h4 className="font-semibold text-foreground mb-2">Lab Environment</h4>
                        <p className="text-sm text-muted-foreground">24/7 access to cloud lab environments</p>
                      </div>
                      <div className="text-center">
                        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <span className="text-green-600 text-2xl">👨‍🏫</span>
                        </div>
                        <h4 className="font-semibold text-foreground mb-2">Expert Mentorship</h4>
                        <p className="text-sm text-muted-foreground">1-on-1 sessions with industry experts</p>
                      </div>
                      <div className="text-center">
                        <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <span className="text-purple-600 text-2xl">🏆</span>
                        </div>
                        <h4 className="font-semibold text-foreground mb-2">Project Portfolio</h4>
                        <p className="text-sm text-muted-foreground">Build impressive projects for your portfolio</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </main>

      <Footer />
    </div>
  );
}
