import Header from "@/components/header";
import Footer from "@/components/footer";
import HeroSection from "@/components/hero-section";
import Ticker from "@/components/ticker";
import CourseCard from "@/components/course-card";
import ServiceCard from "@/components/service-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle, Laptop, Users, Crown, Check } from "lucide-react";
import { useEffect, useRef } from "react";

export default function Home() {
  const sectionsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    }, observerOptions);

    sectionsRef.current.forEach(el => {
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const addToRefs = (el: HTMLDivElement) => {
    if (el && !sectionsRef.current.includes(el)) {
      sectionsRef.current.push(el);
    }
  };

  const courses = [
    {
      title: "Azure DevOps Mastery",
      badge: "Upskill",
      badgeColor: "blue" as const,
      students: "150+",
      rating: "4.9",
      level: "Intermediate to Advanced Level",
      features: [
        "Azure Pipelines & CI/CD automation",
        "Infrastructure as Code with ARM/Bicep", 
        "Container orchestration & monitoring",
        "Azure security & compliance automation",
        "Career transition & certification support"
      ],
      isPopular: true
    },
    {
      title: "AWS DevOps Professional",
      badge: "Upskill",
      badgeColor: "orange" as const,
      students: "120+",
      rating: "4.8", 
      level: "Intermediate to Advanced Level",
      features: [
        "AWS CodePipeline & CodeDeploy mastery",
        "Terraform & CloudFormation IaC",
        "EKS, Lambda & serverless automation",
        "AWS security best practices",
        "AWS certification preparation"
      ]
    },
    {
      title: "AI-Powered DevOps",
      badge: "Upskill", 
      badgeColor: "purple" as const,
      students: "80+",
      rating: "4.9",
      level: "Advanced Level",
      features: [
        "AI-driven monitoring & alerting",
        "Machine learning for operations",
        "Automated incident response", 
        "Predictive analytics for infrastructure",
        "AI strategy for enterprise DevOps"
      ]
    }
  ];

  const services = [
    {
      title: "IT Staffing",
      description: "Connect with top talent and opportunities in DevOps, cloud engineering, and AI-powered infrastructure roles.",
      features: [
        "DevOps Engineer placements",
        "Cloud Architect positions", 
        "Site Reliability Engineer roles",
        "Contract and permanent positions"
      ],
      imageUrl: "https://images.unsplash.com/photo-1552581234-26160f608093?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
      imageAlt: "IT staffing and recruitment services",
      buttonText: "Find Opportunities"
    },
    {
      title: "Software Development",
      description: "Full-stack development services with DevOps integration, CI/CD pipelines, and cloud-native applications.",
      features: [
        "Cloud-native application development",
        "Microservices architecture",
        "DevOps pipeline integration", 
        "Containerized solutions"
      ],
      imageUrl: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
      imageAlt: "Software development team working together",
      buttonText: "Start Project"
    },
    {
      title: "Multi-cloud Solutions",
      description: "Design and implement robust multi-cloud strategies across AWS, Azure, and Google Cloud platforms.",
      features: [
        "Cross-cloud migration strategies",
        "Hybrid cloud architectures",
        "Cost optimization across platforms",
        "Multi-cloud monitoring & security"
      ],
      imageUrl: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
      imageAlt: "Multi-cloud infrastructure solutions", 
      buttonText: "Get Consultation"
    },
    {
      title: "Digital Marketing",
      description: "AI-powered marketing automation, analytics, and growth strategies for technology companies and professionals.",
      features: [
        "AI-driven content marketing",
        "Technical SEO & performance",
        "LinkedIn & professional branding",
        "Marketing automation pipelines"
      ],
      imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
      imageAlt: "Digital marketing professionals at work",
      buttonText: "Boost Growth"
    },
    {
      title: "Cloud-based Services", 
      description: "End-to-end cloud solutions including migration, optimization, monitoring, and managed services.",
      features: [
        "Cloud migration & modernization",
        "24/7 managed cloud services",
        "Performance optimization",
        "Disaster recovery & backup"
      ],
      imageUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
      imageAlt: "Cloud computing and digital services",
      buttonText: "Learn More"
    },
    {
      title: "Job Assistance",
      description: "Comprehensive career support including resume building, interview preparation, and direct placement opportunities.",
      features: [
        "Resume & LinkedIn optimization",
        "Mock interviews & feedback",
        "Direct placement partnerships",
        "Salary negotiation guidance"
      ],
      imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
      imageAlt: "Career guidance and job placement assistance",
      buttonText: "Get Placed"
    }
  ];

  return (
    <div className="min-h-screen">
      <Header />
      
      <HeroSection />

      {/* DevOps Impact Alert */}
      <section className="bg-red-50 border-l-4 border-red-500 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <AlertTriangle className="text-red-500 text-xl" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-red-800">DevOps Skills Alert</h3>
              <p className="text-sm text-red-700">Stay ahead in the rapidly evolving cloud and DevOps landscape</p>
            </div>
          </div>
        </div>
      </section>

      <Ticker />

      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-foreground mb-8">Don't Get Left Behind - Master DevOps Today!</h2>
          <Button size="lg" className="shadow-lg" data-testid="start-transformation-button">
            Start Your Transformation
          </Button>
        </div>
      </section>

      {/* Courses Section */}
      <section className="py-20 bg-secondary/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div ref={addToRefs} className="text-center mb-16 scroll-fadeIn">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">Transform Your Future</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Choose from our comprehensive DevOps and cloud courses designed for every career stage, from beginners to advanced professionals
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {courses.map((course, index) => (
              <div key={index} ref={addToRefs} className="scroll-fadeIn">
                <CourseCard {...course} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div ref={addToRefs} className="text-center mb-16 scroll-fadeIn">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">Our Complete Service Portfolio</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              From training to placement, we provide end-to-end solutions for your DevOps and cloud career journey
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} ref={addToRefs} className="scroll-fadeIn">
                <ServiceCard {...service} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Learning Excellence */}
      <section className="py-20 bg-secondary/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div ref={addToRefs} className="text-center mb-16 scroll-fadeIn">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">Learning Excellence</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Multiple pathways to master DevOps with expert guidance and comprehensive support
            </p>
          </div>

          {/* Stats Row */}
          <div ref={addToRefs} className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16 scroll-fadeIn">
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">1000+</div>
              <div className="text-muted-foreground">Professionals Trained</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">200+</div>
              <div className="text-muted-foreground">Hours of Content</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">75+</div>
              <div className="text-muted-foreground">Workshop Sessions</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">10+</div>
              <div className="text-muted-foreground">Expert Instructors</div>
            </div>
          </div>

          {/* Learning Modes */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div ref={addToRefs} className="scroll-fadeIn">
              <Card className="h-full shadow-lg hover:shadow-xl transition-shadow border border-border">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-blue-100 rounded-xl flex items-center justify-center mb-6">
                    <Laptop className="text-blue-600 text-2xl" />
                  </div>
                  <h3 className="text-2xl font-bold text-card-foreground mb-4">Online Workshops</h3>
                  <p className="text-muted-foreground mb-6">
                    Interactive sessions with live coding, real-time Q&A, and collaborative learning experiences from anywhere in the world.
                  </p>
                  <ul className="space-y-3 mb-8">
                    {[
                      "Live Interactive Sessions",
                      "Real-time Q&A Support", 
                      "Screen Sharing & Collaboration",
                      "Recorded Sessions Access",
                      "Digital Resources & Materials"
                    ].map((feature, index) => (
                      <li key={index} className="flex items-center space-x-3">
                        <Check className="text-green-500 w-4 h-4" />
                        <span className="text-card-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button className="w-full" data-testid="online-workshops-learn-more">
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            </div>

            <div ref={addToRefs} className="scroll-fadeIn">
              <Card className="h-full shadow-lg hover:shadow-xl transition-shadow border border-border">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-green-100 rounded-xl flex items-center justify-center mb-6">
                    <Users className="text-green-600 text-2xl" />
                  </div>
                  <h3 className="text-2xl font-bold text-card-foreground mb-4">Offline Workshops</h3>
                  <p className="text-muted-foreground mb-6">
                    In-person intensive training with hands-on mentorship, networking opportunities, and immersive learning environment.
                  </p>
                  <ul className="space-y-3 mb-8">
                    {[
                      "Face-to-face Mentorship",
                      "Hands-on Lab Sessions",
                      "Networking Opportunities", 
                      "Small Group Interactions",
                      "Physical Learning Materials"
                    ].map((feature, index) => (
                      <li key={index} className="flex items-center space-x-3">
                        <Check className="text-green-500 w-4 h-4" />
                        <span className="text-card-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button className="w-full" data-testid="offline-workshops-learn-more">
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            </div>

            <div ref={addToRefs} className="scroll-fadeIn">
              <Card className="h-full shadow-lg hover:shadow-xl transition-shadow border border-border">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-purple-100 rounded-xl flex items-center justify-center mb-6">
                    <Crown className="text-purple-600 text-2xl" />
                  </div>
                  <h3 className="text-2xl font-bold text-card-foreground mb-4">Masterclasses</h3>
                  <p className="text-muted-foreground mb-6">
                    Premium sessions by industry experts, thought leaders, and sharing cutting-edge insights and advanced techniques.
                  </p>
                  <ul className="space-y-3 mb-8">
                    {[
                      "Industry Expert Sessions",
                      "Advanced Technique Training",
                      "Exclusive Content Access",
                      "Direct Expert Interaction", 
                      "Premium Learning Materials"
                    ].map((feature, index) => (
                      <li key={index} className="flex items-center space-x-3">
                        <Check className="text-green-500 w-4 h-4" />
                        <span className="text-card-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button className="w-full" data-testid="masterclasses-learn-more">
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
