import Header from "@/components/header";
import Footer from "@/components/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContactSchema, type InsertContact } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { MapPin, Phone, MessageCircle, Instagram } from "lucide-react";

export default function Contact() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertContact>({
    resolver: zodResolver(insertContactSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      interest: "",
      message: ""
    }
  });

  const submitContact = useMutation({
    mutationFn: async (data: InsertContact) => {
      const response = await apiRequest("POST", "/api/contacts", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Message sent successfully!",
        description: "We'll get back to you within 24 hours.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/contacts"] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to send message",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: InsertContact) => {
    submitContact.mutate(data);
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: "Address",
      value: "Hyderabad, Telangana, India",
      color: "blue"
    },
    {
      icon: Phone,
      title: "Phone",
      value: "+91 9494034647",
      color: "green"
    },
    {
      icon: MessageCircle,
      title: "WhatsApp", 
      value: "+91 9494034647",
      color: "purple",
      link: "https://wa.me/919494034647"
    },
    {
      icon: Instagram,
      title: "Instagram",
      value: "@NextGen_AI_Skills",
      color: "pink",
      link: "https://instagram.com/NextGen_AI_Skills"
    }
  ];

  const interestOptions = [
    { value: "azure-devops", label: "Azure DevOps" },
    { value: "aws-devops", label: "AWS DevOps" },
    { value: "ai-devops", label: "AI for DevOps" },
    { value: "multi-cloud", label: "Multi-cloud Solutions" },
    { value: "job-assistance", label: "Job Assistance" },
    { value: "it-staffing", label: "IT Staffing" },
    { value: "software-development", label: "Software Development" },
    { value: "digital-marketing", label: "Digital Marketing" }
  ];

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">Get In Touch</h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Ready to start your DevOps journey? Contact us today and let's discuss how we can help you achieve your career goals.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold text-foreground mb-6">Contact Information</h3>
                <div className="space-y-6">
                  {contactInfo.map((info, index) => (
                    <div key={index} className="flex items-start space-x-4">
                      <div className={`w-12 h-12 bg-${info.color}-100 rounded-lg flex items-center justify-center flex-shrink-0`}>
                        <info.icon className={`text-${info.color}-600 text-xl`} />
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground mb-1">{info.title}</h4>
                        {info.link ? (
                          <a 
                            href={info.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-muted-foreground hover:text-primary transition-colors"
                            data-testid={`contact-${info.title.toLowerCase()}`}
                          >
                            {info.value}
                          </a>
                        ) : (
                          <p className="text-muted-foreground">{info.value}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex space-x-4">
                <a
                  href="https://wa.me/919494034647"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-green-500 text-white px-6 py-3 rounded-xl hover:bg-green-600 transition-colors flex items-center space-x-2"
                  data-testid="whatsapp-contact-button"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Chat on WhatsApp</span>
                </a>
                <a
                  href="https://instagram.com/NextGen_AI_Skills"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-pink-500 text-white px-6 py-3 rounded-xl hover:bg-pink-600 transition-colors flex items-center space-x-2"
                  data-testid="instagram-contact-button"
                >
                  <Instagram className="w-4 h-4" />
                  <span>Follow Us</span>
                </a>
              </div>
            </div>

            {/* Contact Form */}
            <Card className="shadow-lg border border-border">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-card-foreground mb-6">Send us a Message</h3>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name *</Label>
                      <Input
                        id="firstName"
                        {...form.register("firstName")}
                        placeholder="Enter your first name"
                        className="mt-2"
                        data-testid="input-first-name"
                      />
                      {form.formState.errors.firstName && (
                        <p className="text-destructive text-sm mt-1">
                          {form.formState.errors.firstName.message}
                        </p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name *</Label>
                      <Input
                        id="lastName"
                        {...form.register("lastName")}
                        placeholder="Enter your last name"
                        className="mt-2"
                        data-testid="input-last-name"
                      />
                      {form.formState.errors.lastName && (
                        <p className="text-destructive text-sm mt-1">
                          {form.formState.errors.lastName.message}
                        </p>
                      )}
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      {...form.register("email")}
                      placeholder="Enter your email address"
                      className="mt-2"
                      data-testid="input-email"
                    />
                    {form.formState.errors.email && (
                      <p className="text-destructive text-sm mt-1">
                        {form.formState.errors.email.message}
                      </p>
                    )}
                  </div>
                  
                  <div>
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input
                      id="phone"
                      type="tel"
                      {...form.register("phone")}
                      placeholder="Enter your phone number"
                      className="mt-2"
                      data-testid="input-phone"
                    />
                    {form.formState.errors.phone && (
                      <p className="text-destructive text-sm mt-1">
                        {form.formState.errors.phone.message}
                      </p>
                    )}
                  </div>
                  
                  <div>
                    <Label htmlFor="interest">Area of Interest *</Label>
                    <Select onValueChange={(value) => form.setValue("interest", value)} data-testid="select-interest">
                      <SelectTrigger className="mt-2">
                        <SelectValue placeholder="Select your area of interest" />
                      </SelectTrigger>
                      <SelectContent>
                        {interestOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {form.formState.errors.interest && (
                      <p className="text-destructive text-sm mt-1">
                        {form.formState.errors.interest.message}
                      </p>
                    )}
                  </div>
                  
                  <div>
                    <Label htmlFor="message">Message *</Label>
                    <Textarea
                      id="message"
                      {...form.register("message")}
                      rows={4}
                      placeholder="Tell us about your goals and how we can help"
                      className="mt-2"
                      data-testid="textarea-message"
                    />
                    {form.formState.errors.message && (
                      <p className="text-destructive text-sm mt-1">
                        {form.formState.errors.message.message}
                      </p>
                    )}
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={submitContact.isPending}
                    data-testid="submit-contact-form"
                  >
                    {submitContact.isPending ? "Sending..." : "Send Message"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Additional Contact Options */}
          <div className="mt-16 text-center">
            <h2 className="text-3xl font-bold text-foreground mb-8">Other Ways to Connect</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="text-center">
                <CardContent className="p-6">
                  <Phone className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-foreground mb-2">Call Us Directly</h3>
                  <p className="text-muted-foreground mb-4">Speak with our admission counselors</p>
                  <a 
                    href="tel:+919494034647" 
                    className="text-primary hover:underline"
                    data-testid="direct-call-link"
                  >
                    +91 9494034647
                  </a>
                </CardContent>
              </Card>
              
              <Card className="text-center">
                <CardContent className="p-6">
                  <MessageCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-foreground mb-2">WhatsApp Support</h3>
                  <p className="text-muted-foreground mb-4">Get instant support and course info</p>
                  <a 
                    href="https://wa.me/919494034647" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-green-500 hover:underline"
                    data-testid="whatsapp-support-link"
                  >
                    Chat Now
                  </a>
                </CardContent>
              </Card>
              
              <Card className="text-center">
                <CardContent className="p-6">
                  <Instagram className="w-12 h-12 text-pink-500 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-foreground mb-2">Follow Us</h3>
                  <p className="text-muted-foreground mb-4">Stay updated with latest news</p>
                  <a 
                    href="https://instagram.com/NextGen_AI_Skills" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-pink-500 hover:underline"
                    data-testid="instagram-follow-link"
                  >
                    @NextGen_AI_Skills
                  </a>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
