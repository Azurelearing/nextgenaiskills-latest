import Header from "@/components/header";
import Footer from "@/components/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, Calendar, Handshake, Briefcase, Users, Code, Zap, TrendingUp, Clock } from "lucide-react";

export default function Community() {
  const communityFeatures = [
    {
      icon: MessageCircle,
      title: "Active Discussion Forums",
      description: "Engage in technical discussions, share solutions, and learn from experienced professionals in our dedicated community forums.",
      benefits: ["24/7 active discussions", "Expert moderators", "Solution sharing", "Peer learning"]
    },
    {
      icon: Calendar,
      title: "Regular Meetups & Events", 
      description: "Attend monthly meetups, networking events, and tech talks featuring industry leaders and successful alumni.",
      benefits: ["Monthly tech meetups", "Industry expert speakers", "Networking sessions", "Virtual & in-person events"]
    },
    {
      icon: Handshake,
      title: "Mentorship Program",
      description: "Get paired with experienced DevOps professionals who can guide your career journey and provide personalized advice.",
      benefits: ["1-on-1 mentoring", "Career guidance", "Skill development", "Industry insights"]
    },
    {
      icon: Briefcase,
      title: "Job Referral Network",
      description: "Access exclusive job opportunities through our alumni network working at top tech companies worldwide.",
      benefits: ["Exclusive job postings", "Alumni referrals", "Interview preparation", "Salary negotiation tips"]
    }
  ];

  const communityStats = [
    { number: "1000+", label: "Active Members", icon: Users },
    { number: "50+", label: "Monthly Events", icon: Calendar },
    { number: "95%", label: "Placement Rate", icon: TrendingUp },
    { number: "200+", label: "Success Stories", icon: Zap }
  ];

  const upcomingEvents = [
    {
      title: "Azure DevOps Best Practices",
      date: "March 15, 2024",
      time: "7:00 PM IST", 
      type: "Online Workshop",
      speaker: "Senior DevOps Engineer at Microsoft"
    },
    {
      title: "AWS Cost Optimization Strategies",
      date: "March 22, 2024", 
      time: "6:30 PM IST",
      type: "Masterclass",
      speaker: "Cloud Architect at Amazon"
    },
    {
      title: "Kubernetes Security Deep Dive",
      date: "March 29, 2024",
      time: "8:00 PM IST",
      type: "Technical Session", 
      speaker: "Security Expert at Red Hat"
    }
  ];

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">Join Our Thriving Community</h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Connect with fellow DevOps professionals, share knowledge, and grow your career together in our vibrant community
            </p>
          </div>

          {/* Community Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
            {communityStats.map((stat, index) => (
              <Card key={index} className="text-center">
                <CardContent className="p-6">
                  <stat.icon className="w-8 h-8 text-primary mx-auto mb-4" />
                  <div className="text-3xl font-bold text-primary mb-2">{stat.number}</div>
                  <div className="text-muted-foreground">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Community Features */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1515187029135-18ee286d815b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Professional networking and community collaboration" 
                className="rounded-2xl shadow-lg w-full"
              />
            </div>
            
            <div className="space-y-8">
              {communityFeatures.map((feature, index) => (
                <div key={index} className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-foreground mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground mb-4">{feature.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {feature.benefits.map((benefit, benefitIndex) => (
                        <Badge key={benefitIndex} variant="secondary" className="text-xs">
                          {benefit}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
              
              <div className="pt-6">
                <Button size="lg" data-testid="join-community-button">
                  Join Community
                </Button>
              </div>
            </div>
          </div>

          {/* Upcoming Events */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-8 text-center">Upcoming Events</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {upcomingEvents.map((event, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <Badge className="mb-4">{event.type}</Badge>
                    <h3 className="text-lg font-bold text-foreground mb-3">{event.title}</h3>
                    <div className="space-y-2 text-sm text-muted-foreground mb-4">
                      <p><Calendar className="w-4 h-4 inline mr-2" />{event.date}</p>
                      <p><Clock className="w-4 h-4 inline mr-2" />{event.time}</p>
                      <p><Users className="w-4 h-4 inline mr-2" />{event.speaker}</p>
                    </div>
                    <Button className="w-full" variant="outline" data-testid={`register-${index}`}>
                      Register Now
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Community Benefits */}
          <Card className="bg-secondary/30">
            <CardContent className="p-8">
              <h2 className="text-3xl font-bold text-foreground mb-8 text-center">Why Join Our Community?</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Code className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-bold text-foreground mb-2">Learn Together</h3>
                  <p className="text-muted-foreground">Share knowledge, solve problems, and grow together with like-minded professionals.</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="text-lg font-bold text-foreground mb-2">Network & Connect</h3>
                  <p className="text-muted-foreground">Build meaningful professional relationships and expand your network.</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="w-8 h-8 text-purple-600" />
                  </div>
                  <h3 className="text-lg font-bold text-foreground mb-2">Advance Your Career</h3>
                  <p className="text-muted-foreground">Get access to exclusive opportunities and career advancement resources.</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* CTA Section */}
          <div className="text-center mt-16">
            <h2 className="text-3xl font-bold text-foreground mb-6">Ready to Connect?</h2>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Join our community today and start building meaningful connections that will accelerate your DevOps career
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" data-testid="join-now-button">
                Join Community Now
              </Button>
              <Button variant="outline" size="lg" data-testid="learn-more-button">
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
