import Header from "@/components/header";
import Footer from "@/components/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function About() {
  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">About NextGen AI Skills</h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Empowering Tomorrow's AI Leaders through cutting-edge DevOps and cloud training
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            <div>
              <h2 className="text-3xl font-bold text-foreground mb-6">Our Mission</h2>
              <p className="text-lg text-muted-foreground mb-6">
                At NextGen AI Skills, we believe in empowering professionals with the skills they need to thrive in an AI-driven world. 
                Our focus on DevOps, cloud infrastructure, and AI integration helps bridge the gap between traditional IT operations 
                and modern, intelligent automation.
              </p>
              <p className="text-lg text-muted-foreground mb-6">
                Located in Hyderabad, Telangana, we serve students and professionals across India and beyond, providing comprehensive 
                training that combines theoretical knowledge with hands-on practical experience.
              </p>
            </div>
            
            <div>
              <img 
                src="https://images.unsplash.com/photo-1515187029135-18ee286d815b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Professional team collaboration"
                className="rounded-2xl shadow-lg w-full"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <Card className="text-center p-8">
              <CardContent>
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-blue-600 text-2xl">🎯</span>
                </div>
                <h3 className="text-xl font-bold text-foreground mb-4">Our Vision</h3>
                <p className="text-muted-foreground">
                  To be the leading provider of AI-integrated DevOps education, creating a workforce ready for the future of technology.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-8">
              <CardContent>
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-green-600 text-2xl">💡</span>
                </div>
                <h3 className="text-xl font-bold text-foreground mb-4">Our Approach</h3>
                <p className="text-muted-foreground">
                  Hands-on learning with real-world projects, industry mentorship, and comprehensive career support from day one.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-8">
              <CardContent>
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-purple-600 text-2xl">🚀</span>
                </div>
                <h3 className="text-xl font-bold text-foreground mb-4">Our Impact</h3>
                <p className="text-muted-foreground">
                  1000+ professionals trained, 95% placement rate, and partnerships with leading tech companies worldwide.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <h2 className="text-3xl font-bold text-foreground mb-8">Why Choose NextGen AI Skills?</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center">
                <Badge className="bg-blue-100 text-blue-600 text-lg p-3 mb-4">Expert Faculty</Badge>
                <p className="text-sm text-muted-foreground">Industry professionals with 10+ years experience</p>
              </div>
              <div className="text-center">
                <Badge className="bg-green-100 text-green-600 text-lg p-3 mb-4">Practical Learning</Badge>
                <p className="text-sm text-muted-foreground">Real-world projects and hands-on labs</p>
              </div>
              <div className="text-center">
                <Badge className="bg-purple-100 text-purple-600 text-lg p-3 mb-4">Career Support</Badge>
                <p className="text-sm text-muted-foreground">End-to-end placement assistance</p>
              </div>
              <div className="text-center">
                <Badge className="bg-orange-100 text-orange-600 text-lg p-3 mb-4">Flexible Learning</Badge>
                <p className="text-sm text-muted-foreground">Online, offline, and hybrid options</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
