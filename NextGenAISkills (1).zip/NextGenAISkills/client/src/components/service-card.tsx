import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface ServiceCardProps {
  title: string;
  description: string;
  features: string[];
  imageUrl: string;
  imageAlt: string;
  buttonText: string;
  onAction?: () => void;
}

export default function ServiceCard({
  title,
  description,
  features,
  imageUrl,
  imageAlt,
  buttonText,
  onAction
}: ServiceCardProps) {
  return (
    <Card className="shadow-lg hover:shadow-xl transition-shadow border border-border">
      <CardContent className="p-6">
        <img 
          src={imageUrl} 
          alt={imageAlt} 
          className="w-full h-40 object-cover rounded-lg mb-4" 
        />
        <h3 className="text-xl font-bold text-card-foreground mb-3">{title}</h3>
        <p className="text-muted-foreground mb-4">{description}</p>
        <ul className="space-y-2 text-sm text-card-foreground mb-6">
          {features.map((feature, index) => (
            <li key={index}>• {feature}</li>
          ))}
        </ul>
        <Button 
          className="w-full" 
          onClick={onAction}
          data-testid={`service-${title.toLowerCase().replace(/\s+/g, "-")}`}
        >
          {buttonText}
        </Button>
      </CardContent>
    </Card>
  );
}
