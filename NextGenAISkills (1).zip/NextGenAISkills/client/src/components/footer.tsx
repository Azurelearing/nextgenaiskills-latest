import { Link } from "wouter";
import { Network } from "lucide-react";

export default function Footer() {
  const quickLinks = [
    { name: "Home", href: "/" },
    { name: "About Us", href: "/about" },
    { name: "Courses", href: "/courses" },
    { name: "Curriculum", href: "/curriculum" },
    { name: "Contact", href: "/contact" },
  ];

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Network className="text-primary-foreground text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-bold">NextGen AI Skills</h1>
                <p className="text-sm text-gray-400">Empowering Tomorrow's AI Leaders</p>
              </div>
            </div>
            <p className="text-gray-400 mb-6 max-w-md">
              Leading the way in DevOps and cloud training, helping professionals master the skills needed for tomorrow's technology landscape.
            </p>
            <div className="flex space-x-4">
              <a
                href="https://wa.me/919494034647"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center hover:bg-green-700 transition-colors"
                data-testid="footer-whatsapp"
              >
                <span className="text-sm">📱</span>
              </a>
              <a
                href="https://instagram.com/NextGen_AI_Skills"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-pink-600 rounded-lg flex items-center justify-center hover:bg-pink-700 transition-colors"
                data-testid="footer-instagram"
              >
                <span className="text-sm">📷</span>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-gray-400 hover:text-white transition-colors"
                    data-testid={`footer-link-${link.name.toLowerCase().replace(" ", "-")}`}
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <ul className="space-y-2 text-gray-400">
              <li className="flex items-center space-x-2">
                <span className="text-sm">📍</span>
                <span>Hyderabad, Telangana, India</span>
              </li>
              <li className="flex items-center space-x-2">
                <span className="text-sm">📞</span>
                <span>+91 9494034647</span>
              </li>
              <li className="flex items-center space-x-2">
                <span className="text-sm">📱</span>
                <span>+91 9494034647</span>
              </li>
              <li className="flex items-center space-x-2">
                <span className="text-sm">📷</span>
                <span>@NextGen_AI_Skills</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-400">
            © 2024 NextGen AI Skills. All rights reserved. Empowering Tomorrow's AI Leaders.
          </p>
        </div>
      </div>
    </footer>
  );
}
