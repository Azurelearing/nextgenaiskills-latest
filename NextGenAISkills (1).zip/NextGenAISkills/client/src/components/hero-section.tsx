import { Button } from "@/components/ui/button";
import { useState } from "react";

export default function HeroSection() {
  const [selectedInterest, setSelectedInterest] = useState<string>("");

  const interests = [
    "Azure DevOps",
    "AWS DevOps", 
    "Cloud Infrastructure",
    "AI for DevOps",
    "Multi-cloud Solutions",
    "Job Assistance"
  ];

  return (
    <section className="hero-gradient min-h-[90vh] flex items-center">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-4xl md:text-6xl font-bold text-primary-foreground mb-6 leading-tight">
              Start Your <span className="text-yellow-300">DevOps Journey</span>
            </h1>
            <p className="text-xl text-primary-foreground/90 mb-8 max-w-2xl">
              Join 1000+ professionals mastering Azure DevOps, AWS DevOps, and cloud infrastructure for the future
            </p>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 mb-8">
              <h3 className="text-lg font-semibold text-primary-foreground mb-4">Select Your Interest</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {interests.map((interest) => (
                  <button
                    key={interest}
                    onClick={() => setSelectedInterest(interest)}
                    className={`px-3 py-2 rounded-lg text-sm transition-colors ${
                      selectedInterest === interest
                        ? "bg-white/30 text-primary-foreground"
                        : "bg-white/20 hover:bg-white/30 text-primary-foreground"
                    }`}
                    data-testid={`interest-${interest.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    {interest}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                size="lg" 
                className="bg-white text-primary hover:bg-gray-100 shadow-lg"
                data-testid="get-started-button"
              >
                Get Started Now
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="border-2 border-white text-primary-foreground hover:bg-white/10"
                data-testid="explore-courses-button"
              >
                Explore Courses
              </Button>
            </div>
            
            <p className="text-sm text-primary-foreground/80 mt-4">
              By signing up, you agree to receive updates about our courses and programs.
            </p>
          </div>
          
          <div className="flex justify-center lg:justify-end">
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Cloud infrastructure and DevOps technology" 
                className="rounded-2xl shadow-2xl floating-animation w-full max-w-lg" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
