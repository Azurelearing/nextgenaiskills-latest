import { useEffect, useRef } from "react";

export default function Ticker() {
  const tickerRef = useRef<HTMLDivElement>(null);

  const newsItems = [
    "🚀 Major tech companies increase DevOps hiring by 200% for cloud migration projects",
    "📊 Study reveals 85% of enterprises adopt multi-cloud strategies requiring DevOps expertise", 
    "⚡ AWS and Azure certifications show 300% salary increase for DevOps professionals",
    "🔧 Container orchestration with Kubernetes becomes mandatory skill for 90% of DevOps roles",
    "💰 DevOps engineers earn 40% more than traditional IT operations roles",
    "🌐 Remote DevOps positions increase by 500% as companies embrace cloud-first strategies",
    "📈 Infrastructure as Code (IaC) skills demand grows 250% in enterprise environments",
    "🔒 Security-focused DevOps (DevSecOps) roles see 400% growth in financial sector"
  ];

  return (
    <section className="bg-gray-900 text-white py-3 overflow-hidden">
      <div className="ticker">
        <div className="ticker-content" ref={tickerRef}>
          {newsItems.map((item, index) => (
            <span key={index} className="mx-8 whitespace-nowrap">
              {item}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
