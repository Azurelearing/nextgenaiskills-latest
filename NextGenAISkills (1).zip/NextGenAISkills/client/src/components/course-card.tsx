import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Star, Check } from "lucide-react";

interface CourseCardProps {
  title: string;
  badge: string;
  badgeColor: "blue" | "orange" | "purple" | "green";
  students: string;
  rating: string;
  level: string;
  features: string[];
  isPopular?: boolean;
  onEnroll?: () => void;
}

export default function CourseCard({
  title,
  badge,
  badgeColor,
  students,
  rating,
  level,
  features,
  isPopular = false,
  onEnroll
}: CourseCardProps) {
  const badgeColors = {
    blue: "bg-blue-100 text-blue-600",
    orange: "bg-orange-100 text-orange-600", 
    purple: "bg-purple-100 text-purple-600",
    green: "bg-green-100 text-green-600"
  };

  return (
    <Card className="h-full shadow-lg hover:shadow-xl transition-shadow border border-border">
      <CardContent className="p-8">
        <div className="flex items-center justify-between mb-6">
          <Badge className={`${badgeColors[badgeColor]} text-sm font-medium`}>
            {badge}
          </Badge>
          {isPopular && (
            <Badge className="bg-green-100 text-green-600 text-sm font-medium">
              Most Popular
            </Badge>
          )}
        </div>
        
        <h3 className="text-2xl font-bold text-card-foreground mb-2">{title}</h3>
        <div className="flex items-center space-x-4 mb-4">
          <span className="text-3xl font-bold text-primary">{students}</span>
          <div className="flex items-center text-yellow-500">
            <Star className="w-4 h-4 fill-current" />
            <span className="ml-1">{rating}</span>
          </div>
        </div>
        <p className="text-primary text-sm font-medium mb-6">{level}</p>
        
        <ul className="space-y-3 mb-8">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start space-x-3">
              <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
              <span className="text-card-foreground">{feature}</span>
            </li>
          ))}
        </ul>
        
        <Button 
          className="w-full" 
          onClick={onEnroll}
          data-testid={`enroll-${title.toLowerCase().replace(/\s+/g, "-")}`}
        >
          Explore Now
        </Button>
      </CardContent>
    </Card>
  );
}
